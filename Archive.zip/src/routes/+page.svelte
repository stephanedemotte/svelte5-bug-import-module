<script>
  import { test } from "../lib/Test.svelte";
</script>

{test}
