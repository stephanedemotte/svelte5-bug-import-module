<script module>
  export const test = "test";
</script>
